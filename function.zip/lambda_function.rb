def client
  @client ||= Line::Bot::Client.new { |config|
    config.channel_id = ENV["LINE_CHANNEL_ID"]
    config.channel_secret = ENV["LINE_CHANNEL_SECRET"]
    config.channel_token = ENV["LINE_CHANNEL_TOKEN"]
  }
end

def lambda_handler(event:, context:)
    puts "event: ", event
    puts "context: ", context.inspect
    
    # ヘッダがあるときだけ署名チェック
    headers = event["headers"]
    signiture = headers['X-Line-Signature'] if headers
    
    # 
    events = client.parse_events_from(event)
    p events
    p headers
    { statusCode: 200, body: JSON.generate('Hello from Lambda!') }
end